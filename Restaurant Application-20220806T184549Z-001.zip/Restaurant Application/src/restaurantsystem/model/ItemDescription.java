package restaurantsystem.model;

public abstract class ItemDescription {
	protected abstract void ItemQualityDescription();

}
